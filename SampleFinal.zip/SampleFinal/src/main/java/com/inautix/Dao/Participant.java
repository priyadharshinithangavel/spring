package com.inautix.Dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import com.bkg.inautix.model.ParticipantBean;
import com.inautix.connection.DBConnection;

public class Participant {
	List<ParticipantBean> l1=new ArrayList<ParticipantBean>(); 
	public List<ParticipantBean> viewParticipant()
	{
	Statement stmt=null;
	DBConnection db=new DBConnection();
	Connection con=db.getConnection();
	List InsertList = null;
	ResultSet result=null;
	String str;
	str="select * from T_XBBNHHJ_Participant";
	try {
		stmt=con.createStatement();
	} catch (SQLException e1) {
		System.out.println("Error occured!");
	}
	try {
		result= stmt.executeQuery(str);
		while(result.next())
		{
			ParticipantBean pb=new ParticipantBean();
			pb.setParticipant_clg_no(result.getString(1));
			pb.setParticipant_name(result.getString(2));
			pb.setParticipant_qualification(result.getString(3));
			pb.setParticipant_phone(result.getString(4));
			pb.setParticipant_address(result.getString(5));
			l1.add(pb);
			
		}
	} catch (SQLException e) {
		System.out.println("Error occured!");
	}
	return l1;
	}
	public List insertParticipant(ParticipantBean par)
	{
		List<ParticipantBean> list=new ArrayList<ParticipantBean>();
		list.add(par);
		PreparedStatement stmt=null;
		String str="";
		String str1="";
		String str3="";
		ResultSet result=null;
		String t_name ="";
		int e_id=0;
		DBConnection db=new DBConnection();
		Connection con=db.getConnection();
		str="insert into T_XBBNHHJ_Participant values(?,?,?,?,?)";
		try {
			stmt=con.prepareStatement(str);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			stmt.setString(1,par.getParticipant_clg_no());
			System.out.println(par.getParticipant_clg_no());
			stmt.setString(2, par.getParticipant_name());
			
			stmt.setString(3, par.getParticipant_qualification());
			stmt.setString(4, par.getParticipant_phone());
			stmt.setString(5, par.getParticipant_address());
		}
		catch (SQLException e1) {
			System.out.println("During setting the values in participant table");
		}
		try {
			stmt.executeUpdate();
	}catch(Exception e){
		
	}
		return list;
}
}
