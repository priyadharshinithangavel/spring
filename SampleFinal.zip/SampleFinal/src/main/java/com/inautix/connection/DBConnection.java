package com.inautix.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

	public class DBConnection {
		Connection con=null;
		public Connection getConnection()
		{
			try {
				Class.forName("org.apache.derby.jdbc.ClientDriver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			try {
				con=DriverManager.getConnection("jdbc:derby://172.24.18.11:1527/sports","user","pwd");
			} catch (SQLException e) {
				e.printStackTrace();
		}
			return con;
		}


	}

