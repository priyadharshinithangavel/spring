package com.bkg.inautix.model;


public class ParticipantBean {
	String participant_clg_no;
	String participant_name;
	String participant_qualification;
	String participant_phone;
	String participant_address;
	public String getParticipant_clg_no() {
		return participant_clg_no;
	}
	public void setParticipant_clg_no(String participant_clg_no) {
		this.participant_clg_no = participant_clg_no;
	}
	public String getParticipant_name() {
		return participant_name;
	}
	public void setParticipant_name(String participant_name) {
		this.participant_name = participant_name;
	}
	public String getParticipant_qualification() {
		return participant_qualification;
	}
	public void setParticipant_qualification(String participant_qualification) {
		this.participant_qualification = participant_qualification;
	}
	public String getParticipant_phone() {
		return participant_phone;
	}
	public void setParticipant_phone(String participant_phone) {
		this.participant_phone = participant_phone;
	}
	public String getParticipant_address() {
		return participant_address;
	}
	public void setParticipant_address(String participant_address) {
		this.participant_address = participant_address;
	}
}
