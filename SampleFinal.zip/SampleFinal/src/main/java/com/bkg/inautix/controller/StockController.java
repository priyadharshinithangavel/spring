package com.bkg.inautix.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bkg.inautix.model.ParticipantBean;
import com.inautix.Dao.Participant;

@RestController
@RequestMapping(value = "/stocks")
public class StockController {
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<ParticipantBean> getAllStocks() {
		Participant p = new Participant();
		ArrayList<ParticipantBean> list = (ArrayList<ParticipantBean>) p.viewParticipant();
		return list;
	}

	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public List<ParticipantBean> insert(@RequestBody ParticipantBean pb) {
		Participant p = new Participant();
		ArrayList list = (ArrayList) p.insertParticipant(pb);
		return list;
	}

}
