create table T_XBBNHHJ_Participant(participant_clg_no varchar(6) primary key,
participant_name varchar(20),
participant_qualification varchar(20),
participant_phone varchar(10),
participant_address varchar(30));

insert into T_XBBNHHJ_Participant values('p101','Ravi','B.sc','9999999999','salem');
select * from T_XBBNHHJ_PARTICIPANT;