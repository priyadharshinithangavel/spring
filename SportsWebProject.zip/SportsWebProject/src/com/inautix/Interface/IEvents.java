package com.inautix.Interface;

import com.inautix.Bean.EventBean;

public interface IEvents {
	public int updateData(EventBean eb) ;
	public void deleteEvent(String eid);
	public void viewParticipants();
}
