package com.inautix.Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.inautix.Dao.ParticipantDao;

@WebServlet("/InserData")
public class InserData extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(Validate.class);
	public InserData() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("uname");
		String password = request.getParameter("pwd");
		String type = request.getParameter("myList");
		logger.info(type);
		logger.info(username + " " + password);
		ParticipantDao pd = new ParticipantDao();
		try {
			if (!type.equals(null)) {
				int i = pd.register(username, password, type);
				if (i == 1) {
					response.setContentType("text/html");
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Incorrect UserName or Password..');");
					out.println("</script>");
					if(i==1)
					{
						out.print("Registered successfully");
					RequestDispatcher rd = request.getRequestDispatcher("/login.html");
					rd.forward(request, response);
					}
				} else {
					out.print("<html>");
					out.print("<body>");
					out.print("<h3><center>something went wrong try again!</center></h3>");
					out.println("</body>");
					out.print("</html>");
					RequestDispatcher rd = request.getRequestDispatcher("/registersite.html");
					rd.include(request, response);
				}
			}
		} catch (Exception e) {
			out.print("<html><body>");
			out.print("<center><h1>Error occurs try again</h1></center>");
			out.print("</body></html>");
		}
	}
}
