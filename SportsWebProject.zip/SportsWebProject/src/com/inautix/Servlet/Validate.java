package com.inautix.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import org.apache.log4j.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

import com.inautix.Dao.ParticipantDao;
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(Validate.class);
   
    public Validate() {
       super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
	
				response.setContentType("text/html");
				String username=request.getParameter("uname");
				String password=request.getParameter("pwd");
				PrintWriter out=response.getWriter();
				logger.info(username+" "+password);
				try
				{
				ParticipantDao pd =new ParticipantDao(); 
				String type=pd.login(username, password);
				logger.info("type of person: "+type);
				if(type!=null)
				{	
					HttpSession session = request.getSession(true);
					String uname = (String) session.getAttribute(username); 
					session.setAttribute("username", uname);
					session.setAttribute("type", type);
					if(type.equals("user"))
					{
						RequestDispatcher rd=request.getRequestDispatcher("Participant.jsp");  
						rd.forward(request, response);
					}
					else if(type.equals("admin"))
					{
						RequestDispatcher rd1=request.getRequestDispatcher("adminaction.jsp");  
						rd1.forward(request, response); 	
					}
					else if(type.equals("organiser"))
					{
						RequestDispatcher rd1=request.getRequestDispatcher("organiser.jsp");  
						rd1.forward(request, response); 	
					}
				}
				else
				{	
					out.print("<html>");
					out.print("<body ");
					out.print("<br><br><h3><b><center>Username or password incorrect!</center><b></h3>");  
					out.println("</body>");
					out.print("</html>");
			        RequestDispatcher rd=request.getRequestDispatcher("/login.html");  
			        rd.forward(request, response); 
				}	
		    }catch(Exception e)
		    {
		    	e.printStackTrace();
		    	out.print("<html><body>");
				out.print("<center><h1>Error occurs try again</h1></center>");
				out.print("</body></html>");
		    }
	}
}

