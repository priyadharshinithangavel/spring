package com.inautix.Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.Bean.EventBean;
import com.inautix.Dao.AdminDao;


@WebServlet("/InsertEvent")
public class InsertEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public InsertEvent() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		EventBean eb=new EventBean();
		String id1=request.getParameter("id");
		eb.setEvent_id(Integer.parseInt(id1));
		eb.setEvent_name(request.getParameter("ename"));
		eb.setTeam_one(request.getParameter("tone"));
		eb.setTeam_two(request.getParameter("ttwo"));
		String nos=request.getParameter("no");
		eb.setNo_of_participant(Integer.parseInt(nos)); 
		eb.setEvent_date(request.getParameter("date"));
		eb.setEvent_place(request.getParameter("address"));
		eb.setEvent_organiser(request.getParameter("oname"));
		String fees=request.getParameter("fee");
		eb.setFees(Double.parseDouble(fees)); 
		AdminDao ad=new AdminDao();
		int no=ad.updateData(eb);
		if(no==1)
		{

			out.print("<html>");
			out.print("<body ");
			out.print("<br><br><h3><b><center>Event added Successfully!</center><b></h3>");  
			out.println("</body>");
			out.print("</html>");
	        RequestDispatcher rd=request.getRequestDispatcher("/insertevent.jsp");  
	        rd.include(request, response); 
		}
		else
		{
			out.print("<html>");
			out.print("<body ");
			out.print("<br><br><div color=white><h3><center><b>Sorry given data has error!</center><b></div></h3>");  
			out.println("</body>");
			out.print("</html>");
	        RequestDispatcher rd=request.getRequestDispatcher("/insertevent.jsp");  
	        rd.include(request, response); 
		}
	}

}
