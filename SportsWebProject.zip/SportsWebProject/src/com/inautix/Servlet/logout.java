package com.inautix.Servlet;

import java.io.IOException;  
import java.io.PrintWriter;  

import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.http.HttpSession;  

import org.apache.log4j.Logger;
public class logout extends HttpServlet {  
	final static Logger logger = Logger.getLogger(Validate.class);
	   
        protected void doGet(HttpServletRequest request, HttpServletResponse response)  

                                throws ServletException, IOException {  
        	System.out.println("inside");
            response.setContentType("text/html");  
            PrintWriter out=response.getWriter();           
            HttpSession session=request.getSession(); 
            logger.info("inside the logout servlet");
            session.invalidate();    
            out.print("<HTML><H1>You are successfully logged out!</H1></HTML>");  
                          request.getRequestDispatcher("index.html").forward(request, response);  
            out.close();  

    }  

}  

