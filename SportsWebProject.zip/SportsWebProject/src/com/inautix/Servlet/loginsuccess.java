package com.inautix.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.Bean.ParticipantBean;
import com.inautix.Dao.ParticipantDao;
import com.inautix.Event.DBConnection;



@WebServlet("/loginsuccess")
public class loginsuccess extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
   
    public loginsuccess() {
        super();
       
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DBConnection db=new DBConnection();
		Connection con=db.getConnection();
		Statement stmt=null;
		ResultSet result=null;
		int id=0;
		ParticipantBean pb=new ParticipantBean();
		String query="select participant_clg_no from T_XBBNHHJ_Participant ";
		try {
			stmt=con.createStatement();
			result=stmt.executeQuery(query);
		} catch (SQLException e) {
			System.out.println("Error occured!");
		}
		try {
		while(result.next())
			{
			id=result.getInt(1);
		}
		} catch (SQLException e) {
			System.out.println("error!!");
			e.printStackTrace();
			}
		id=id+1;
		pb.setParticipant_clg_no(id);
		HttpSession session=request.getSession(false);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		ParticipantDao pd =new ParticipantDao(); 
		String name=request.getParameter("name");
		pb.setParticipant_name(name);
		String qlty=request.getParameter("qalf");
		pb.setParticipant_qualification(qlty);
		String phn=request.getParameter("phone");
		pb.setParticipant_phone(phn);
		String add=request.getParameter("address");
		pb.setParticipant_address(add);
		String ename=(String)session.getAttribute("ename");
		pb.setEname(ename);
		String teamid=request.getParameter("tid");
		int tid=Integer.parseInt(teamid);
		pb.setTid(tid);	
		try {
			int i=pd.registerforEvent(pb);
			System.out.println(i);
			if(i==1)
			{
			out.println("<html><body><br><br><h5><b>Registered Successfully...<b></h5>");
			out.println("<h5><b>Your Participant id is:"+id+"<b><h5>");
			out.println("</body></html>");
			 RequestDispatcher rd=request.getRequestDispatcher("/Participant.jsp");  
		        rd.include(request, response); 
			}
			else if(i==2)
			{
				out.println("<html><body>");
				out.println("<br><h1>Sorry Registration can not be done Try Again..</h1>");
				out.println("</body></html>");
				RequestDispatcher rd2=request.getRequestDispatcher("/Participant.jsp");  
				rd2.include(request, response); 
			}
			else
			{
				out.println("<html><body>");
				out.println("<br><h1>Sorry Registration can not be done since it is completed..</h1>");
				out.println("</body></html>");
				RequestDispatcher rd2=request.getRequestDispatcher("/Participant.jsp");  
				rd2.include(request, response); 	
			}
		} catch (SQLException e) {
			System.out.println("error occured");
			e.printStackTrace();
		}
	}
		
	}

	

