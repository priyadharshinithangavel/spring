package com.inautix.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inautix.Bean.Data;
import com.inautix.Bean.ErrorDetails;
import com.inautix.Bean.EventBean;
import com.inautix.Bean.MetaData;
import com.inautix.Bean.Response;
import com.inautix.Dao.TestDaoImpl;

@RestController
public class TestController {
	
	
	@Autowired
	TestDaoImpl testDaoimpl;
	@Autowired
	MetaData metaData;

	@Autowired
	Data data;
	@Autowired
	Response response;
	
	@Autowired
	ErrorDetails errorDetails;
	
	@RequestMapping(value="/tests", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
		
	public Response getAllTestDetails()
	{	
		List<EventBean> testList;
		try {
			testList = testDaoimpl.getAllTests();
			saveMetaData(true,"Tests loaded","12345");
			saveData(null, testList);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			errorDetails.setCode("00005");
			errorDetails.setDescription(e.getMessage());;
			saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,errorDetails);
		}
		return response;
	}
	private void saveResponse(Data data, MetaData metaData, ErrorDetails errorDet) {
		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDet);
	}
	private void saveData(ErrorDetails erroDet, List testObj) {
		response.setError(erroDet);
			data.setOutput(testObj);
		
	}
	private void saveMetaData(boolean success, String description, String responseId){
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	

}
