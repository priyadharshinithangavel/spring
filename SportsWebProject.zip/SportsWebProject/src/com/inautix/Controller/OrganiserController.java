package com.inautix.Controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inautix.Bean.ParticipantBean;
import com.inautix.Dao.ParticipantDao;

@RestController
@RequestMapping(value = "/sports")
public class OrganiserController {

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<ParticipantBean> getAllStocks() {
		System.out.print("inside");
		ParticipantDao p = new ParticipantDao();
		List list = new ArrayList<ParticipantBean>();
		 list = p.viewparticipants();
		return list;
	}
}
