package com.inautix.Dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.inautix.Bean.EventBean;
import com.inautix.Event.DBConnection;
public class EventDao {

		public List getHoldings()
		{
			Statement stmt=null;
			List holdingsList = null;
			DBConnection db=new DBConnection();
			Connection con=db.getConnection();
			try {
				stmt=con.createStatement();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			String str="select * from T_XBBNHHJ_Events";
			ResultSet result=null;
			try {
				result=stmt.executeQuery(str);
				 holdingsList = new ArrayList<EventBean>();
				System.out.println("Event Details");
				while(result.next())
				{
					EventBean evntb=new EventBean();
					evntb.setEvent_id(result.getInt(1));
					evntb.setEvent_name(result.getString(2));
					evntb.setTeam_one(result.getString(3));
					evntb.setTeam_two(result.getString(4));
					evntb.setNo_of_participant(result.getInt(5));
					evntb.setEvent_date(result.getString(6));
					evntb.setEvent_place(result.getString(7));
					evntb.setEvent_organiser(result.getString(8));
					evntb.setFees(result.getDouble(9));
					holdingsList.add(evntb);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally{
				try {
					result.close();
					if(stmt != null)					
					stmt.close();				
					con.commit();
					if(con != null)
					con.close();
				}			
				 catch (SQLException e) {
						e.printStackTrace();
					}
			}
			return holdingsList;
		}
		



}
