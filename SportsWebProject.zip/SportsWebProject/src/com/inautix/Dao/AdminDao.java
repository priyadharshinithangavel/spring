package com.inautix.Dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

import com.inautix.Event.DBConnection;
import com.inautix.Interface.IEvents;
import com.inautix.Bean.AdminBean;
import com.inautix.Bean.EventBean;

	
	public class AdminDao implements IEvents{
		Scanner input=new Scanner(System.in);
		

		public int updateData(EventBean eb)  {
		
			PreparedStatement stmt=null; 
			ResultSet result=null;
			String str="";
			String str2="";
			String str3="";
			String query="";
			int team_id=0;
			DBConnection db=new DBConnection();
			Connection con=db.getConnection();
			str="insert into T_XBBNHHJ_Events values(?,?,?,?,?,?,?,?,?)";
			try {
				stmt=con.prepareStatement(str);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				System.out.println(eb.getEvent_id());
				stmt.setInt(1,eb.getEvent_id());
				stmt.setString(2, eb.getEvent_name());
				stmt.setString(3, eb.getTeam_one());
				stmt.setString(4,eb.getTeam_two());
				stmt.setInt(5, eb.getNo_of_participant());
				stmt.setString(6, eb.getEvent_date());
				stmt.setString(7,eb.getEvent_place());
				stmt.setString(8, eb.getEvent_organiser());
				stmt.setDouble(9, eb.getFees());
				}
				catch (SQLException e1) {
					System.out.println("Error occured!");
				}
			try {
				stmt.executeUpdate();
				System.out.println("Inserted Succesfully");
				
			} catch (SQLException e2) {
				e2.printStackTrace();
				return 0;
			}
			str3="select count(team_id) from T_XBBNHHJ_Team";
			try {
				stmt=con.prepareStatement(str3);
			} catch (SQLException e2) {
				System.out.println("sql statement is wrong");
				
			}
			try {
				 result=stmt.executeQuery();
				 while(result.next())
				 {
				 team_id=result.getInt(1);
				
				 }
				}catch (SQLException e1) {
					System.out.println("Error during execution");
			}
			str2="insert into T_XBBNHHJ_Team(team_id,team_name,count_participant,event_id) values(?,?,?,?)";
			try {
				stmt=con.prepareStatement(str2);
			} catch (SQLException e2) {
				System.out.println("sql statement is wrong");
			}
			team_id=team_id+1;
			 System.out.println(team_id);
			 System.out.println(eb.getTeam_one());
			 System.out.println(eb.getEvent_id());
			try {
				stmt.setInt(1, team_id);
				stmt.setString(2, eb.getTeam_one());
				stmt.setInt(3, 0);
				stmt.setInt(4, eb.getEvent_id());
			} catch (SQLException e2) {
				System.out.println("Error occur during setting the value");
			}
			
			try {
				int rst=stmt.executeUpdate();
				System.out.println("inserted the first team in team table");
				}catch (SQLException e1) {
					e1.printStackTrace();
				}
			query="insert into T_XBBNHHJ_Team(team_id,team_name,count_participant,event_id) values(?,?,?,?)";
			try {
				stmt=con.prepareStatement(query);
			} catch (SQLException e2) {
				System.out.println("sql statement is wrong");
			}
			team_id=team_id+1;
			try {
				stmt.setInt(1, team_id);
				stmt.setString(2, eb.getTeam_two());
				stmt.setInt(3, 0);
				stmt.setInt(4, eb.getEvent_id());
			} catch (SQLException e2) {
				System.out.println("Error occur during setting the value");
			}
			try {
				int rst=stmt.executeUpdate();
				System.out.println("inserted the second team in team table");
				}catch (SQLException e1) {
					e1.printStackTrace();
				}
			finally{
				try {
					if(stmt != null)					
					stmt.close();				
					con.commit();
					if(con != null)
					con.close();
				}			
				 catch (SQLException e) {
						e.printStackTrace();
					}
			}
			return 1;
		}

		public void deleteEvent(String eid) {
			Statement stmt=null;
			DBConnection db=new DBConnection();
			Connection con=db.getConnection();
			String str="";
			int ieid=Integer.parseInt(eid);
			str="delete from T_XBBNHHJ_Events where event_id="+ieid;
			try {
				stmt=con.createStatement();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				stmt.execute(str);
				System.out.println("Deleted successfully");
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
			finally{
				try {
					if(stmt != null)					
					stmt.close();				
					con.commit();
					if(con != null)
					con.close();
				}			
				 catch (SQLException e) {
						e.printStackTrace();
					}
			}
			
			
		}

		public void viewParticipants() {
			Statement stmt=null;
			DBConnection db=new DBConnection();
			Connection con=db.getConnection();
			List InsertList = null;
			ResultSet result=null;
			String str="";
			str="select * from T_XBBNHHJ_Participant";
			try {
				stmt=con.createStatement();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			try {
				result=stmt.executeQuery(str);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				System.out.println("...Participant Details....");
				System.out.format("%-20s %-20s %-30s %-20s %-20s\n","participant_clg_no","participant_name","participant_qualification","participant_phone","participant_address");
				while(result.next())
				{
					System.out.format("%-20s %-20s %-30s %-20s %-20s\n",result.getString(1),result.getString(2),result.getString(3),result.getString(4),result.getString(5));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		




}
