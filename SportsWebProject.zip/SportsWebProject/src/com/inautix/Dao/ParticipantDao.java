package com.inautix.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.inautix.Bean.ParticipantBean;
import com.inautix.Event.DBConnection;

public class ParticipantDao {

		public String login(String loginid, String password) {
			PreparedStatement stmt=null;
			List InsertList = null;
			String str="";
			int count=0;
			ResultSet result=null;
			DBConnection db=new DBConnection();
			Connection con=db.getConnection();
			str="select loginid,password,typeofperson from T_XBBNHHJ_UserLogin";
			try {
				stmt=con.prepareStatement(str);
			} catch (SQLException e) {
				e.printStackTrace();
			}
				try {
				result=stmt.executeQuery();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			try {
				while(result.next()){
	                String dbUsername = result.getString(1);
	                String dbPassword = result.getString(2);
	                if(dbUsername.equals(loginid) && dbPassword.equals(password)){
	                    String type=result.getString(3);
	                    return type;
	                }
			}} catch (SQLException e1) {
				e1.printStackTrace();
				System.out.println("Error occured!");
				return "not a user";
			}
			finally{
				try {
					result.close();
					if(stmt != null)					
					stmt.close();				
					con.commit();
					if(con != null)
					con.close();
				}			
				 catch (SQLException e) {
						e.printStackTrace();
					}
			}
			return "not a user";
			
		}
		
		public int register(String id,String pass,String type) {
			PreparedStatement stmt=null;
			String str="";
			DBConnection db=new DBConnection();
			Connection con=db.getConnection();
			String loginid=id;
			str="insert into T_XBBNHHJ_UserLogin values(?,?,?)";
			try {
				stmt=con.prepareStatement(str);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				stmt.setString(1,loginid);
				stmt.setString(2, pass);
				stmt.setString(3, type);
				}
				catch (SQLException e1) {
					e1.printStackTrace();
					System.out.println("Error occured!");
				}
				try {
					stmt.executeUpdate();
					return 1;
				} catch (SQLException e2) {
					e2.printStackTrace();
					System.out.println("Error occured!");
				}
				finally{
					try {
						if(stmt != null)					
						stmt.close();				
						con.commit();
						if(con != null)
						con.close();
					}			
					 catch (SQLException e) {
							e.printStackTrace();
						}
				}
			return 0;
		}
		
		public int registerforEvent(ParticipantBean pb) throws SQLException {
			PreparedStatement stmt=null;
			String str="";
			String str1="";
			String str3="";
			ResultSet result=null;
			String t_name ="";
			int e_id=0;
			DBConnection db=new DBConnection();
			Connection con=db.getConnection();
			str="insert into T_XBBNHHJ_Participant values(?,?,?,?,?,?,?)";
			try {
				stmt=con.prepareStatement(str);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
			stmt.setInt(1,pb.getParticipant_clg_no());
			stmt.setString(2, pb.getParticipant_name());
			stmt.setString(3,pb.getParticipant_qualification() );
			stmt.setString(4, pb.getParticipant_phone());
			stmt.setString(5, pb.getParticipant_address());
			stmt.setString(6, pb.getEname());
			stmt.setInt(7, pb.getTid());
			}
			catch (SQLException e1) {
				System.out.println("During setting the values in participant table");
			}
			try {
				int t=validate(pb.getParticipant_clg_no(),pb.getEname(),pb.getTid());
				System.out.println(t);
				if(t!=0){
				stmt.executeUpdate();
				System.out.println("Registered successfully");
						str3="update T_XBBNHHJ_TEAM set count_participant=? where team_id=?";
						stmt=con.prepareStatement(str3);
						stmt.setInt(1, t);
						stmt.setInt(2, pb.getTid());
						try {
							int rst=stmt.executeUpdate();
							System.out.println("inserted count value in the team table");
							return 1;
							}catch (SQLException e1) {
								e1.printStackTrace();
								return 0;
							}
						
					}
				else
					return 0;
			} catch (SQLException e2) {
				System.out.println("Error occured!");
				e2.printStackTrace();
				return 0;
			}
			finally{
				try {
					if(stmt != null)					
					stmt.close();				
					con.commit();
					if(con != null)
					con.close();
				}			
				 catch (SQLException e) {
						e.printStackTrace();
					}
			}
			
		}


		private int validate(int p_id, String ename, Integer team_id) throws SQLException {
			PreparedStatement stmt=null;
			String str="";
			String str1="";
			String str2="";
			String str3="";
			ResultSet result=null;
			ResultSet countrsl=null;
			int total=0;
			int count=0;
			DBConnection db=new DBConnection();
			Connection con=db.getConnection();
			System.out.println(ename);
			str1="select no_of_participants from T_XBBNHHJ_Events where event_name =(?)";
			stmt=con.prepareStatement(str1);
			stmt.setString(1, ename);
			result=stmt.executeQuery();
			while(result.next())
			{
			total=result.getInt(1);
			}
			str2="select count(*) from T_XBBNHHJ_Team group by team_id having team_id=(?)";
			stmt=con.prepareStatement(str2);
			stmt.setInt(1, team_id);
			result=stmt.executeQuery();
			while(result.next())
			{
			count=result.getInt(1);
			}
			System.out.println(total);
			System.out.println(count);
			if(count>=total)
			{
				System.out.println("Already registeration completed!!!");
				return 0;
			}
			return count;
		}
		
		public List<ParticipantBean> viewparticipants() {
			Statement stmt=null;
			DBConnection db=new DBConnection();
			Connection con=db.getConnection();
			List list = new ArrayList<ParticipantBean>();
			ResultSet result=null;
			String str="";
			str="select * from T_XBBNHHJ_Participant";
			try {
				stmt=con.createStatement();
			} catch (SQLException e1) {
				System.out.println("Error occured!");
			}
			try {
				result = stmt.executeQuery(str);
				while(result.next())
				{
					ParticipantBean pb=new ParticipantBean();
					pb.setParticipant_clg_no(result.getInt(1));
					pb.setParticipant_name(result.getString(2));
					pb.setParticipant_qualification(result.getString(3));
					pb.setParticipant_phone(result.getString(4));
					pb.setParticipant_address(result.getString(5));
					pb.setEname(result.getString(6));
					pb.setTid(result.getInt(7));
					list.add(pb);
				}
			} catch (SQLException e) {
				System.out.println("Error occured!");
			}
			return list;		
		}
}
