package com.inautix.Dao;

import java.sql.Types;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.inautix.Bean.EventBean;
import com.nxn.tra.api.rowmapper.TestRowMapper;


@Component
public class TestDaoImpl extends JdbcDaoSupport {

	@Autowired
	public TestDaoImpl(DataSource datasource) {
		// TODO Auto-generated constructor stub
		setDataSource(datasource);
	}

	public List<EventBean> getAllTests() throws Exception {
		// TODO Auto-generated method stub
		List<EventBean> testList = null;

		testList = getJdbcTemplate().query("select * from T_XBBNHHJ_Events",
				new Object[] {}, new TestRowMapper());

		return testList;
	}




}
