package com.inautix.Bean;

public class EventBean {
		
			int event_id;
			String event_name;
			String team_one;
			String team_two;
			int no_of_participant;
			String event_date;
			String event_place;
			String event_organiser;
			Double fees;
			public Double getFees() {
				return fees;
			}
			public void setFees(Double fees) {
				this.fees = fees;
			}
			public int getEvent_id() {
				return event_id;
			}
			public void setEvent_id(int event_id) {
				this.event_id = event_id;
			}
			public String getEvent_name() {
				return event_name;
			}
			public void setEvent_name(String event_name) {
				this.event_name = event_name;
			}
			public String getTeam_one() {
				return team_one;
			}
			public void setTeam_one(String team_one) {
				this.team_one = team_one;
			}
			public String getTeam_two() {
				return team_two;
			}
			public void setTeam_two(String team_two) {
				this.team_two = team_two;
			}
			public int getNo_of_participant() {
				return no_of_participant;
			}
			public void setNo_of_participant(int no_of_participant) {
				this.no_of_participant = no_of_participant;
			}
			public String getEvent_date() {
				return event_date;
			}
			public void setEvent_date(String event_date) {
				this.event_date = event_date;
			}
			public String getEvent_place() {
				return event_place;
			}
			public void setEvent_place(String event_place) {
				this.event_place = event_place;
			}
			public String getEvent_organiser() {
				return event_organiser;
			}
			public void setEvent_organiser(String event_organiser) {
				this.event_organiser = event_organiser;
			}
			



}
