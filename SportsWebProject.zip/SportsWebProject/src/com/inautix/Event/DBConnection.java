package com.inautix.Event;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

	public class DBConnection {
		Connection con=null;
		public Connection getConnection()
		{
			try {
				Class.forName("org.apache.derby.jdbc.ClientDriver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			try {
				   con=DriverManager.getConnection("jdbc:derby://172.24.21.26:1527/SportEvent","Event","pwd");
			} catch (SQLException e) {
				e.printStackTrace();
		}
			return con;
		}


	}



