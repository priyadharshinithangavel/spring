package com.nxn.tra.api.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.inautix.Bean.EventBean;
public class TestRowMapper implements RowMapper<EventBean> {

	public EventBean mapRow(ResultSet rs, int rownum) throws SQLException {
		
		EventBean testObj =new EventBean();
		testObj.setEvent_id(rs.getInt(1));
		testObj.setEvent_name(rs.getString(2));
		testObj.setTeam_one(rs.getString(3));
		testObj.setTeam_two(rs.getString(4));
		testObj.setNo_of_participant(rs.getInt(5));
		testObj.setEvent_date(rs.getString(6));
		testObj.setEvent_place(rs.getString(7));
		testObj.setEvent_organiser(rs.getString(8));
		testObj.setFees(rs.getDouble(9));
		return testObj;
		
	}

}
