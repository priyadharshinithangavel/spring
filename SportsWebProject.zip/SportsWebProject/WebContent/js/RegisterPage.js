function validate()
{
	var name=document.getElementById("name").value;
	if(name=="")
		{
		alert("Name field is empty");
		return false;
		}
	var qlty=document.getElementById("qalf").value;
	if(qlty=="")
	{
	alert("Qualification field is empty");
	return false;
	}
	var phone= document.getElementById("phone").value;
	if(phone.length<10 || phone.length>10)
	{
	alert("phone number should be ten digit");
	return false;
	}
	var address=document.getElementById("address").value;
	if(address=="")
	{
	alert("address field is empty");
	return false;
	}
	
	return true;
}

function logout()
{
	alert("You are logging out");
}
function preventBack(){window.history.forward();}
setTimeout("preventBack()", 0);
window.onunload=function(){null};

