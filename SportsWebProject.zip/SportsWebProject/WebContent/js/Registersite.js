function registerpage()
{	
	var name= document.getElementById("username").value;
		if(name.length<5)
		{
		alert("username is week character must be greater than five");
		return false;
		}
		var pass= document.getElementById("password").value;
		if(pass.length<8)
		{
		alert("password field is week");
		return false;
		}
		return true;
}