function showregisterform()
{
	document.getElementById('registerform').hidden=false;
}
function noRegistration()
{
	var x;
	if(confirm("we would like you to register anyways.please press ok to register and cancel to register without interest")==true){
		x="You pressed ok!";
	}else{
		x="pressed cancel!";
	}
	document.getElementById("idButtonNO").disabled=true;
}
function Register()
{	
	var input= document.getElementById("name").value;
	var input1= document.getElementById("email").value;
	if(input.length==0)
		alert("name field is empty");
	if(input1.length==0)
		alert("email field is empty");
}